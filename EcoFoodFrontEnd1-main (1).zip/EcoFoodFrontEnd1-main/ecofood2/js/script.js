
const modal = document.getElementById("authModal");
const loginBtn = document.querySelector(".login-btn");
const closeBtn = document.querySelector(".close");
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const recoverForm = document.getElementById("recoverForm");

loginBtn.addEventListener("click", () => {
  modal.classList.remove("hidden");
  loginForm.classList.remove("hidden");
  registerForm.classList.add("hidden");
  recoverForm.classList.add("hidden");
});

closeBtn.addEventListener("click", () => {
  modal.classList.add("hidden");
});

document.getElementById("loginTab").addEventListener("click", () => {
  loginForm.classList.remove("hidden");
  registerForm.classList.add("hidden");
  recoverForm.classList.add("hidden");
});

document.getElementById("registerTab").addEventListener("click", () => {
  loginForm.classList.add("hidden");
  registerForm.classList.remove("hidden");
  recoverForm.classList.add("hidden");
});

document.getElementById("recoverTab").addEventListener("click", () => {
  loginForm.classList.add("hidden");
  registerForm.classList.add("hidden");
  recoverForm.classList.remove("hidden");
});

function login() {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;
  alert(`Bienvenido ${email}`);
}

function register() {
  const name = document.getElementById("registerName").value;
  const email = document.getElementById("registerEmail").value;
  alert(`Registro exitoso de ${name} con el correo ${email}`);
}

function recoverPassword() {
  const email = document.getElementById("recoverEmail").value;
  alert(`Correo de recuperación enviado a ${email}`);
}
